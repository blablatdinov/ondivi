from dataclasses import dataclass

@dataclass
class User(object):

    name: str
    age: int

def greet(user: User):
    print('Long string in initial commit ################################################################################')
    print(f'Hello, {user.name}!')
    print('Long string in new commit ################################################################################')

if __name__ == '__main__':
    greet(User(345, 23))
    greet(User('Bob', '23'))
