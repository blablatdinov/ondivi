def greet(name):
    print('Long string in initial commit ################################################################################')
    print(f'Hello, {name}!')
    print('Long string in new commit ################################################################################')

if __name__ == '__main__':
    greet(input())
